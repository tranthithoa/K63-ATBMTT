﻿namespace DaBang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.tbDuLieuDaGiaiMa = new System.Windows.Forms.TextBox();
            this.btGiaiMa = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbDuLieuDaMaHoa = new System.Windows.Forms.TextBox();
            this.btMaHoa = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbDuLieuCanMaHoa = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 378);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 17);
            this.label3.TabIndex = 23;
            this.label3.Text = "Dữ liệu giải mã được";
            // 
            // tbDuLieuDaGiaiMa
            // 
            this.tbDuLieuDaGiaiMa.Location = new System.Drawing.Point(20, 398);
            this.tbDuLieuDaGiaiMa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbDuLieuDaGiaiMa.Multiline = true;
            this.tbDuLieuDaGiaiMa.Name = "tbDuLieuDaGiaiMa";
            this.tbDuLieuDaGiaiMa.Size = new System.Drawing.Size(557, 110);
            this.tbDuLieuDaGiaiMa.TabIndex = 22;
            // 
            // btGiaiMa
            // 
            this.btGiaiMa.Location = new System.Drawing.Point(20, 334);
            this.btGiaiMa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btGiaiMa.Name = "btGiaiMa";
            this.btGiaiMa.Size = new System.Drawing.Size(100, 28);
            this.btGiaiMa.TabIndex = 21;
            this.btGiaiMa.Text = "Giải mã";
            this.btGiaiMa.UseVisualStyleBackColor = true;
            this.btGiaiMa.Click += new System.EventHandler(this.btGiaiMa_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 194);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "Dữ liệu đã mã hóa";
            // 
            // tbDuLieuDaMaHoa
            // 
            this.tbDuLieuDaMaHoa.Location = new System.Drawing.Point(20, 214);
            this.tbDuLieuDaMaHoa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbDuLieuDaMaHoa.Multiline = true;
            this.tbDuLieuDaMaHoa.Name = "tbDuLieuDaMaHoa";
            this.tbDuLieuDaMaHoa.Size = new System.Drawing.Size(557, 110);
            this.tbDuLieuDaMaHoa.TabIndex = 19;
            // 
            // btMaHoa
            // 
            this.btMaHoa.Location = new System.Drawing.Point(20, 150);
            this.btMaHoa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btMaHoa.Name = "btMaHoa";
            this.btMaHoa.Size = new System.Drawing.Size(100, 28);
            this.btMaHoa.TabIndex = 18;
            this.btMaHoa.Text = "Mã hóa";
            this.btMaHoa.UseVisualStyleBackColor = true;
            this.btMaHoa.Click += new System.EventHandler(this.btMaHoa_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 17);
            this.label1.TabIndex = 17;
            this.label1.Text = "Dữ liệu cần mã hóa";
            // 
            // tbDuLieuCanMaHoa
            // 
            this.tbDuLieuCanMaHoa.Location = new System.Drawing.Point(20, 31);
            this.tbDuLieuCanMaHoa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbDuLieuCanMaHoa.Multiline = true;
            this.tbDuLieuCanMaHoa.Name = "tbDuLieuCanMaHoa";
            this.tbDuLieuCanMaHoa.Size = new System.Drawing.Size(557, 110);
            this.tbDuLieuCanMaHoa.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 554);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbDuLieuDaGiaiMa);
            this.Controls.Add(this.btGiaiMa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbDuLieuDaMaHoa);
            this.Controls.Add(this.btMaHoa);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbDuLieuCanMaHoa);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbDuLieuDaGiaiMa;
        private System.Windows.Forms.Button btGiaiMa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbDuLieuDaMaHoa;
        private System.Windows.Forms.Button btMaHoa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbDuLieuCanMaHoa;
    }
}

